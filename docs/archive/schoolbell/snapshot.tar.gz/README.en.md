# openwrt-modbus-core

[Schoolbell user guide](docs/packages/schoolbell/USER_GUIDE.en.md) — schoolbell 5.0.32 (host checked; router remains 5.0.31).

Schoolbell 5.0.31: target opkg compatibility fixes (no stat dependency, explicit archive directories, owned LuCI cache invalidation). Installation, recovery downgrade and upgrade preserve data and leave automatic bells off; no clock/NTP changes.

Schoolbell 5.0.28: complete engineering IPK and pinned offline bundle; host lifecycle tests, no target installation. [Packaging](docs/packages/schoolbell/PACKAGING.en.md).

5.0.27: clock-result lock contention is pending, not failure; bounded GET waiting, no POST replay. Storage errors are distinct from busy.

Schoolbell 5.0.26: host-only time confirmation/bypass UI and native dependency. Reusable [router clock-drift skill](skills/router-clock-drift/SKILL.md); no hardware logs committed.

Schoolbell 5.0.12: persisted router playback attenuation in Settings; takes effect on the next bell while Mute cancels the current one. The system mixer is unchanged.

Automatic bells: independent fixed/annual bell service, explicit saved-plan activation, Mute and no catch-up playback. Reboot/timezone changes require checking the clock and reactivation. System time and NTP are unchanged.



[Русский](README.md)

A lightweight Lua automation core for OpenWrt with Modbus RTU, state caching,
events and user handlers. Script-only IPKs are built without the OpenWrt SDK.

## Current state

- Core 0.4.0: UCI/procd, status CGI and bounded event journal in `/tmp`.
- Router-only demo; optional BluePill USB RTU polling of DI/DO/AI/PWM.
- `modbus topics`, `echo`, `hz` inspect publications without opening serial.
- WeAct BluePill Plus v1.1 STM32F103C8T6: PA0 button and PB2 system LED.
- Map v2 and Lua example: press counter -> event -> absolute FC05 LED write -> readback.
- Arduino CLI Maple DFU build checks application vectors at `0x08002000` and the 56 KiB limit.

Tested environment: WSL Ubuntu-20.04, OpenWrt 19.07.9 on MR3020 v3,
kernel 4.14.267, Lua 5.1. USB CDC is not electrical RS-485.
RTC and RS-485 gateway are future work; general DO/PWM core writes are not enabled.

## Build and verify

From the repository root in WSL:

```sh
make all
sh scripts/build-bluepill.sh
sh scripts/test-handlers-router.sh
make test-bluepill-router
make test-topics-router
```

The last three commands require router SSH (`ROUTER_HOST`, default `openwrt`).
Handler tests are isolated and do not open live USB; the others inspect the
running system. Without local Lua, `make all` skips Lua tests, not PASS.
CI explicitly installs Lua.

`make build`, `make build-demo`, `make verify`, `make repo` manage artifacts.
`make install-ipk`, `make test-opkg`, `make test-core-demo-router` modify the
router: agree on impact and configuration backup first. `make deploy-core` and
`make deploy-demo` are legacy unmanaged deployment, not the preferred path over
opkg. `make router-clean` removes temporary IPKs/caches; ensure no other process
needs them first.

## Router diagnostics

```sh
modbus topics
modbus echo /devices/1/sample --count 5 --duration 40
modbus hz /devices/1/sample --duration 30
modbus echo /devices/1/system/commands --duration 30
```

Replace `1` with the configured unit ID. Defaults: `profile=none`, system events
disabled. See [firmware/map](firmware/bluepill-modbus/README.md) and
[Lua events/setup](firmware/bluepill-modbus/ROUTER_EVENTS.md).

After confirming the port and agreeing on the UCI change, enable the profile:

```sh
uci set modbus-rtu-core.main.profile=bluepill
uci set modbus-rtu-core.main.device=/dev/ttyACM0
uci set modbus-rtu-core.main.baudrate=115200
uci set modbus-rtu-core.main.parity=N
uci set modbus-rtu-core.main.unit_id=1
uci set modbus-rtu-core.main.request_timeout_ms=500
uci commit modbus-rtu-core
/etc/init.d/modbus-rtu-core restart
```

For button control, additionally enable `system_events` as described in the events guide.

Cache addresses are zero-based. `meta.data_valid` describes the last complete
poll, `meta.last_success` its time; retained values become stale on failure.
System topics publish changes: age/hz describe events, not USB polling rate.
Old presses are not replayed after reconnect. `modbusd` is the sole serial owner.

Journal: `/tmp/modbus/events-core.jsonl` and `.1`, default 65536 bytes per segment,
configured by `event_log_max_bytes`. Oversized JSONL entries (including LF) are
rejected before rotation with an explicit error, without truncating JSON or changing
the journal or seq. File bounds do not bound serialization memory; existing files
after a limit reduction need separate checks. Slow subscribers can lose evicted events;
CLI warns about gaps. Monotonic intervals are independent of RTC/NTP.
`MODBUS_RUNTIME_DIR` overrides the diagnostics/test directory.

## Development

[Agent rules](AGENTS.md), [workflow and specifications](docs/DEVELOPMENT.en.md),
[roadmap](TODO.md), [changelog](CHANGELOG.en.md).
Local tests cover command TTL, incompatible maps, readback errors, Lua snapshots/limits
and journal byte boundaries without hardware.

The Russian-only [technical specification, revision 1.8](docs/core/TECHNICAL_SPECIFICATION.md)
is a draft for agreement, with code/test traceability and explicit coverage gaps.
The owner performs push and land; land requires successful CI for the exact
branch HEAD. New PRs are not required. Research artifacts stay local.

Bench validation results, limitations and upgrade/rollback guidance:
[validation notes](docs/VALIDATION.en.md).

Documentation and archive index: [docs](docs/README.en.md).

Schoolbell sample preview: `make build-schoolbell` (also built by `make all`).
See [package status](docs/packages/schoolbell/README.en.md); no scheduler/player yet.
Build verification requires Python 3.8+ on the host.

[CI — component checks](docs/CI.en.md)

Schoolbell specification 1.7: isolated Lua playback queue, per-resource FIFO, monotonic TTL/UTC, owner cancellation and an injectable player. 24 host test groups; unknown outcomes retain the resource. No core/process/audio/router integration; media-only IPK unchanged. [API](docs/packages/schoolbell/PLAYBACK_QUEUE.en.md).

- [Schoolbell manual sound check page](packages/schoolbell/router-page/README.en.md).

- [Schoolbell saved schedule editor](docs/packages/schoolbell/SCHEDULE_EDITOR.en.md).

- [Schoolbell annual calendar](docs/packages/schoolbell/ANNUAL_CALENDAR.en.md).

Website and interactive demo: [build and publication](site/README.en.md).
