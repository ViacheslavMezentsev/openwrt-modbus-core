# Проверки CI по компонентам

[English](CI.en.md) · [Разработка](DEVELOPMENT.md)

Один workflow `CI - components` запускается на push любой ветки и вручную.
Итоговое задание — `ci-gate`. Перед land проверяйте успешный запуск для точного
HEAD; зелёного отдельного задания недостаточно. Push/land остаются у владельца.
Существующие настройки required checks на GitHub автоматически не меняются.

## Выбор заданий

| Изменения | Задания помимо всегда выполняемых docs/ci-gate |
| --- | --- |
| README/CHANGELOG, обычные Markdown-памятки | Компоненты не нужны |
| Код ядра, firmware, контракт ядра, AGENTS.md | core + demo + schoolbell |
| Код/тесты demo, его ТЗ и другие контрактные документы | demo |
| Код/медиа/проверка schoolbell, его ТЗ и другие контрактные документы | schoolbell |
| Makefile, общие скрипты, CI, зависимости, неизвестный путь | Все компоненты |

README/CHANGELOG в каталогах компонентов — обзорные документы; остальные
файлы `docs/core/` и `docs/packages/<пакет>/` консервативно считаются контрактными.
Изменение ядра проверяет потребителей, но не подтверждает аппаратную совместимость.
Schoolbell пока имеет media-only preview: его job проверяет MP3/manifest и состав
пакета, а не работающий звонок. Demo использует текущие модули ядра в своих тестах.
Firmware запускает доступные core-регрессии; компиляция Arduino остаётся отдельной
задачей, как и аппаратные проверки.

Список путей вычисляется локальным Git diff между before и текущим SHA push,
без rename detection: учитываются обе стороны переноса и удалённые файлы.
Первый push ветки, ручной запуск и недоступная база сравнения дают полный набор.
Последующие push с только обычной документацией пропускают сборку компонентов.
При смешанных изменениях берётся объединение заданий. Workflow целиком не
отфильтровывается через paths-ignore, поэтому общий статус всегда формируется.

## Состав проверок

- `docs`: локальные цели Markdown inline-ссылок и определений ссылок, якоря
  заголовков; строгая проверка всех трёх ТЗ; тесты фильтров и итогового статуса.
- `core`: C++-тест кнопки, core Lua-тесты и синтаксис, сборка/проверка IPK.
- `demo`: Lua-тест настоящего цикла demo, синтаксис, сборка/проверка его IPK.
- `schoolbell`: сборка preview, закреплённые SHA256 медиа и точный состав IPK.
- `ci-gate`: успех changes/docs и каждого назначенного компонента; failure,
  cancellation или неожиданный skipped дают отказ. Пропуск разрешён лишь заданию,
  которое фильтр явно не назначил; отсутствующие/неверные outputs тоже дают отказ.

Компоненты публикуют отдельные artifacts `core-ipk`, `demo-ipk`, `schoolbell-ipk`
с IPK и checksums. При docs-only push новых IPK artifacts нет. Установок на роутер,
звука, serial-доступа и аппаратных reboot в CI нет.

## Локальное воспроизведение

```sh
make check-docs check-ci
make ci-core
make ci-demo
make ci-schoolbell
make all
```

Нужны Python 3.8+, Lua 5.1/luac5.1, g++ и стандартные make/tar/sha256sum.
Компонентные цели core/demo завершаются ошибкой при отсутствии обязательного Lua,
а core — также C++-компилятора; пропущенный обязательный тест не является PASS.
Выходные каталоги `out/ci-core`, `out/ci-demo`, `out/ci-schoolbell` раздельны.
`make all` сохраняет полный прежний прогон и дополнительно проверяет документы/CI.

Валидатор ТЗ находится в `scripts/vendor/embedded-tech-spec/`: неизменённая
копия из закреплённого коммита, manifest с SHA256 и MIT LICENSE. Обновление требует
явного изменения копии/manifest и повторной проверки всех ТЗ; CI не скачивает
валидатор из изменяемой ветки. Проверка Markdown намеренно не проверяет внешние
URL по сети и не является полным Markdown/HTML-рендерером.

После операций Windows Git дополнительно проверяйте `git status` в WSL:
core.filemode=false в Windows может скрыть изменение executable bits.
Не отключайте контроль прав WSL ради чистого дерева.

Семантика [условий заданий](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#jobsjob_idif)
и [контекста needs](https://docs.github.com/en/actions/reference/workflows-and-actions/contexts#needs-context)
описана в GitHub Actions. Воспроизводимые регрессии выбора/итога — scripts/test_ci.py.

Core host-тесты также собирают изолированные Linux C I/O-примитивы: требуются C99 compiler, Linux headers и coreutils timeout; отсутствие инструмента — ошибка. Нативная библиотека не включается в скриптовый IPK.

Schoolbell CI теперь устанавливает Lua 5.1 и запускает make test-schoolbell: календарные тесты и независимый Python datetime oracle; media-only IPK проверяется отдельно. Изменения packages/schoolbell/ и scripts/test-schoolbell.sh выбирают schoolbell.

Сайт проверяется в задании документации через `make check-site`: сборка, локальные ссылки, контраст подписей и модель демо (Python 3 и Node.js). Публикация GitHub Pages — отдельный ручной workflow только из main; см. [инструкцию сайта](../site/README.md).
