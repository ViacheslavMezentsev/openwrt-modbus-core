#!/bin/sh
set -eu

PROJECT_ROOT="$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)"

scope=${1:-all}
case "$scope" in all|core|demo) ;; *) echo 'invalid test scope' >&2; exit 2 ;; esac
if [ "${CI_REQUIRE_TOOLS:-0}" = 1 ]; then
    command -v lua5.1 >/dev/null
    if [ "$scope" != demo ]; then command -v g++ >/dev/null; fi
fi

if [ "$scope" = all ]; then sh "$PROJECT_ROOT/scripts/test-schoolbell.sh"; fi

if [ "$scope" != demo ]; then
    sh "$PROJECT_ROOT/scripts/test-native-io.sh"
    python3 "$PROJECT_ROOT/scripts/test_release_discovery.py"
    python3 "$PROJECT_ROOT/scripts/test_rounds_model.py"
    python3 "$PROJECT_ROOT/scripts/test_transport_states.py"
    python3 "$PROJECT_ROOT/scripts/test_transport_scheduler.py"
    python3 "$PROJECT_ROOT/scripts/test_read_groups.py"
    python3 "$PROJECT_ROOT/scripts/test_device_profiles.py"
    if command -v g++ >/dev/null 2>&1; then
        button_test=$(mktemp /tmp/modbus-button-test.XXXXXX)
        trap 'rm -f "$button_test"' EXIT
        g++ -std=c++11 -Wall -Wextra -Werror "$PROJECT_ROOT/scripts/test_button.cpp" -o "$button_test"
        "$button_test"
        rm -f "$button_test"
        trap - EXIT
    else
        echo '[test] skipped button test: install g++ locally'
    fi
fi

find_lua() {
    for candidate in lua5.1 lua; do
        if command -v "$candidate" >/dev/null 2>&1; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    return 1
}

if LUA_BIN="$(find_lua)"; then
    echo "[test] using $LUA_BIN"
    cd "$PROJECT_ROOT"
    test_dir="$(mktemp -d /tmp/modbus-topics-test.XXXXXX)"
    trap 'rm -rf "$test_dir"' EXIT
    if [ "$scope" != demo ]; then
        "$LUA_BIN" scripts/test_json_strict.lua
        "$LUA_BIN" scripts/test_device_profiles.lua
        "$LUA_BIN" scripts/test_profile_reader.lua
        "$LUA_BIN" scripts/test_transport_state.lua
        "$LUA_BIN" scripts/test_transport_scheduler.lua
        "$LUA_BIN" scripts/test_read_groups.lua
        "$LUA_BIN" scripts/test_io_adapter.lua
        "$LUA_BIN" scripts/test_core.lua "$test_dir/core"
        "$LUA_BIN" scripts/test_rtu.lua
        "$LUA_BIN" scripts/test_topics.lua "$test_dir"
        "$LUA_BIN" scripts/test_handlers.lua "$test_dir"
        "$LUA_BIN" scripts/test_resilience.lua "$test_dir"
        "$LUA_BIN" scripts/test_events.lua "$test_dir"
        "$LUA_BIN" scripts/test_event_registry.lua
    fi
    if [ "$scope" != core ]; then "$LUA_BIN" scripts/test_demo.lua; fi
    exit 0
fi

echo "[test] skipped: install lua5.1 locally to run Lua tests"
